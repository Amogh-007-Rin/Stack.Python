## LAB ASSIGNMENT :- 3.1
## NAME :- AMOGH DATH K A 
## STUDENT ID NUMBER :- 24168333

####################### TOPIC #######################

# WRITE A MENU-DRIVEN PROGRAM THAT ALLOWS THE USER TO MAKE TRANSACTIONS TO A BANK ACCOUNT . 
# THE OPTIONS OF THE MENU ARE :-
# (A) MAKE A DEPOSITE.
# (B) MAKE A WITHDRAWAL.
# (C) OBTAIN A BALLENCE. 
# (D) OUIT

# PROGRAME.

def bank_account():
    print("############ WELCOME TO OUR BANK ############")
    user_name = input("PLEASE ENTER YOUR NAME: ")
    print(f"Welcome, {user_name}")
    balance = 1000  # Initial bank balance as per the question
    print(f"User initial balance is = £{balance}")

    while True:
        print("\nMenu:")
        print("1. MAKE A DEPOSITE .")
        print("2. MAKE A WITHDRAWAL .")
        print("3. OBTAIN A BALLENCE .")
        print("4. QUIT . ")
        
        choice = input("SELECT AN OPTION FROM (1-4): ")

        if choice == '1':
            amount = float(input("ENTER THE AMOUNT TO DEPOSITE : £"))
            if amount > 0:
                balance = amount + balance
                print(f"£{amount} HAS BEEN DEPOSITED .NEW BALANCE: £{balance}")
                print(" THANK YOU FOR USING OUR BANK SERVICE .")
                print(" PLEASE COME VISIT US AGAIN .")
            else:
                print("INVALID AMOUNT. PLEASE ENTER A POSITIVE NUMBER.")
        
        elif choice == '2':
            amount = float(input("ENTER AN AMOUNT TO WITHDRAW : £"))
            if amount > balance:
                print(" IT IS NOT POSSIBLE TO WITHDRAW AN AMOUNT BEYOND THE ACCOUNT BALANCE .")
            elif amount > 0:
                balance -= amount
                print(f"£{amount} HAS BEEN WITHDRAWN . NEW BALANCE: £{balance}")
                print(" THANK YOU FOR USING OUR BANK SERVICE.")
                print("COME VISIT US AGAIN .")
            else:
                print("INVALID AMOUNT. PLEASE ENTER A POSITIVE NUMBER.")
        
        elif choice == '3':
            print(f"YOUR CURRENT BALANCE IS : £{balance}")
            print(" THANK YOU FOR USING OUR BANK SERVICE .")
            print("COME VISIT US AGAIN .")
        
        elif choice == '4' or choice.lower() == 'q':
            print("THANK YOU FOR USING OUR BANK SURVICE . !!!!!!! GOODBYE !!!!")
            print("COME VISIT US AGAIN .")
            break
        
        else:
            print("INVALID OPTION. PLEASE SELECT AN OPTION FROM (1-4).")

if __name__ == "__main__":
    bank_account()


