# Lab1_2  Exercise #3.2
#Compact code / Assignment.1.
# A program to compute the two roots of a quadratic equation.
# the result will be displayed in the terminal. 
# Import the math module to access function "math.sqrt()".

import math

A = float(input("\nEnter the coefficient A: \n"))

B = float(input("\nEnter the coefficient B: \n"))

C = float(input("\nEnter the coefficient C: \n"))

print("\nThe coefficients of the equation are:\n")
print("  Coefficient A = ", A)
print("  Coefficient B = ", B)
print("  Coefficient C = ", C)


# ****Modify that program to compute the two roots of a quadratic equation, as described in the program comments. ****

d = math.sqrt(B * B - 4 * A * C)

root1 = (-B + d) / (
    2 * A
)  # replace 0.0 with the quadratic formula to calculate the roots
root2 = (-B - d) / (2 * A)


print("\nThe roots of the equation:\n")
print(
    "  Root #1 = ", round(root1, 2)
)  # round the result to two decimal places before printing
print("  Root #2 = ", round(root2, 2))


#########################Test########################################
# A = 1, B = 0, C = -4
# Root #1 = (it is 2.0)
# Root #2 = (it is -2.0)

######################
# A = 1, B = 5, C = -36
# Root #1 = 4.0
# Root #2 = -9.0


######################
# A = 2, B = 7.5, C = 6
# Root #1 =  -1.16
# Root  #2 =  -2.59

######################
# A = 0, B = 3.5, C = 8 this test case fails and generates an error (why?):

# Root #1 =  not defined.
# Root #2 =  not defined.

# this test case fails at A=0 because , if A=0 then denominator of the quadratic becomes 0. 
# As denominator of the quadratic becomes 0 the whole quadratic equation becomes not defined .
# Hence A cannot be equal to 0 for a definable quadratic equation .

